import { createSlice } from "@reduxjs/toolkit";

const initialState = {};

const slice = createSlice({
  name: "documents",
  initialState,
  reducers: {},
});

export default slice.reducer;
